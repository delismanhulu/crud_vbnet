﻿Imports System.Data.Odbc
Module Module1

    Public Konek As OdbcConnection
    Public DA As OdbcDataAdapter
    Public DR As OdbcDataReader
    Public DS As DataSet
    Public CMD As OdbcCommand

    Sub KonekDB()
        Try
            Konek = New OdbcConnection("DSN=CRUD_VBNET;MultipleActiveResultSets=True")
            If Konek.State = ConnectionState.Closed Then
                Konek.Open()
            End If
        Catch ex As Exception
            MsgBox("Koneksi Gagal", vbExclamation, "Koneksi Gagal")
        End Try
    End Sub
End Module
