﻿Public Class frmIndex

    Private Sub ADMINToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADMINToolStripMenuItem.Click
        frmCrud.Show()
        frmCrud.BringToFront()
        frmCrud.MdiParent = Me
    End Sub

    Private Sub MASTERToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MASTERToolStripMenuItem.Click
        Form1.ShowDialog()
    End Sub
    Private Sub frmIndex_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        frmCrud.Show()
        frmCrud.BringToFront()
        frmCrud.MdiParent = Me
    End Sub
End Class