﻿Imports System.Data.Odbc
Public Class frmCrud

    Sub tampil_data()
        DA = New OdbcDataAdapter("SELECT * FROM tbl_biodata", Konek)
        DS = New DataSet
        DA.Fill(DS)
        TABEL1.DataSource = DS.Tables(0)
        TABEL1.ReadOnly = True
        TABEL1.Columns(1).Width = 200
        TABEL1.Columns(2).Width = 200

    End Sub

    Sub databaru()
        txtnama.Clear()
        txtalamat.Clear()
        txtkode.Clear()
        txtkode.Focus()
    End Sub
    Sub bersihkan()
        txtnama.Clear()
        txtalamat.Clear()
        txtkode.Clear()
        txtnama.Focus()
    End Sub
    Private Sub frmCrud_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call KonekDB()
        Call tampil_data()
        Call bersihkan()
        txtkode.Enabled = False
    End Sub
    Private Sub btntambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntambah.Click
        Call databaru()
    End Sub
    
    Private Sub btnsimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsimpan.Click
        Try
            If txtnama.Text = "" Then
                MsgBox("Nama tidak boleh kosong", vbExclamation, "Pesan")
                Exit Sub
            ElseIf txtalamat.Text = "" Then
                MsgBox("Alamat tidak boleh kosong", vbExclamation, "Pesan")
                Exit Sub
            Else
                CMD = New OdbcCommand("SELECT * FROM TBL_BIODATA WHERE KODE = '" & txtkode.Text & "'", Konek)
                DR = CMD.ExecuteReader
                DR.Read()
                If Not DR.HasRows Then
                    Dim simpan As String = "insert into tbl_biodata (nama,alamat) value ('" & txtnama.Text & "','" _
                                                                                            & txtalamat.Text & "')"
                    CMD = New OdbcCommand(simpan, Konek)
                    CMD.ExecuteNonQuery()
                    MsgBox("Data berhasil di simpan", vbInformation, "Simpan")
                    Call tampil_data()
                    Call bersihkan()

                Else
                    MsgBox("Data Sudah Ada")
                End If
            End If
        Catch ex As Exception
            MsgBox("Terdapat kesalahan" & ex.Message)
        End Try

    End Sub

    Private Sub btnedit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnedit.Click
        Try
            If txtnama.Text = "" Then
                MsgBox("Nama tidak boleh kosong", vbExclamation, "Pesan")
                Exit Sub
            ElseIf txtalamat.Text = "" Then
                MsgBox("Alamat tidak boleh kosong", vbExclamation, "Pesan")
                Exit Sub
            Else
                CMD = New OdbcCommand("select * from tbl_biodata where kode = '" & txtkode.Text & "'", Konek)
                DR = CMD.ExecuteReader
                DR.Read()
                If DR.HasRows Then
                    Dim edit As String = "update tbl_biodata set nama ='" & txtnama.Text & _
                        "',alamat='" & txtalamat.Text & _
                        "' where kode='" & txtkode.Text & "'"
                    CMD = New OdbcCommand(edit, Konek)
                    CMD.ExecuteNonQuery()
                    MsgBox("Berhasil di edit", vbInformation, "Edit")
                    Call tampil_data()
                    Call bersihkan()

                Else
                    MsgBox("Data belum dipilih")
                    Exit Sub
                End If
            End If
        Catch ex As Exception
            MsgBox("Terdapat kesalahan" & ex.Message)
        End Try
    End Sub

    Private Sub btnhapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhapus.Click
        If txtkode.Text = "" Then
            MsgBox("Data belum di pilih", vbInformation, "Pesan")
            Exit Sub
        Else
            Dim hapusdata As String = "delete from tbl_biodata where kode = '" & txtkode.Text & "'"
            CMD = New OdbcCommand(hapusdata, Konek)
            CMD.ExecuteNonQuery()
            MsgBox("Data berhasil di hapus", vbInformation, "Pesan")
            Call tampil_data()
            Call bersihkan()
        End If
    End Sub

    Private Sub TABEL1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TABEL1.CellContentClick
       
    End Sub

    Private Sub TABEL1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles TABEL1.CellMouseClick
        On Error Resume Next
        txtkode.Text = TABEL1.Rows(e.RowIndex).Cells(0).Value
        CMD = New OdbcCommand("SELECT * FROM TBL_BIODATA WHERE KODE = '" & txtkode.Text & "'", Konek)
        DR = CMD.ExecuteReader
        DR.Read()
        If DR.HasRows Then
            txtkode.Text = DR.Item("KODE")
            txtnama.Text = DR.Item("NAMA")
            txtalamat.Text = DR.Item("ALAMAT")
        End If
    End Sub

    Private Sub txtCari_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCari.TextChanged

        If CBFILTER.SelectedIndex = 0 Then
            DA = New OdbcDataAdapter("select * from tbl_biodata where nama like '" & txtCari.Text & "%'", Konek)
            DS = New DataSet
            DA.Fill(DS)
            TABEL1.DataSource = DS.Tables(0)
        Else
            DA = New OdbcDataAdapter("select * from tbl_biodata where alamat like '" & txtCari.Text & "%'", Konek)
            DS = New DataSet
            DA.Fill(DS)
            TABEL1.DataSource = DS.Tables(0)
        End If
    End Sub
End Class